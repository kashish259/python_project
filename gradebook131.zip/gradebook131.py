
# Student Gradebook Manager
def calculate_grade(avg):
    if avg >= 90:
        return 'A'
    elif avg >= 75:
        return 'B'
    elif avg >= 60:
        return 'C'
    elif avg >= 50:
        return 'D'
    else:
        return 'F'

def student_gradebook_manager():
    students = {}

    while True:
        print("\n1. Add student - Untitled-1:19 - gradebook131.py:19")
        print("2. View all students - Untitled-1:20 - gradebook131.py:20")
        print("3. Search student by name - Untitled-1:21 - gradebook131.py:21")
        print("4. Exit - Untitled-1:22 - gradebook131.py:22")
        choice = input("Enter your choice: ")

        if choice == '1':
            name = input("Enter student name: ").strip()
            try:
                score1 = float(input("Enter marks for Subject 1: "))
                score2 = float(input("Enter marks for Subject 2: "))
                score3 = float(input("Enter marks for Subject 3: "))
            except ValueError:
                print("Invalid input! Please enter numeric values for scores. - Untitled-1:32 - gradebook131.py:32")
                continue

            avg = (score1 + score2 + score3) / 3
            grade = calculate_grade(avg)
            students[name] = {
                'scores': [score1, score2, score3],
                'average': avg,
                'grade': grade
            }
            print(f"Student '{name}' added successfully. - Untitled-1:42 - gradebook131.py:42")

        elif choice == '2':
            if not students:
                print("No students in the system. - Untitled-1:46 - gradebook131.py:46")
            else:
                print("\n--- Student Records - Untitled-1:48 - gradebook131.py:48")
                for name, info in students.items():
                    print(f"Name: {name} - Untitled-1:50 - gradebook131.py:50")
                    print(f"  Scores: {info['scores']} - Untitled-1:51 - gradebook131.py:51")
                    print(f"  Average: {info['average']:.2f} - Untitled-1:52 - gradebook131.py:52")
                    print(f"  Grade: {info['grade']} - Untitled-1:53 - gradebook131.py:53")
                    print("-----------------------")

        elif choice == '3':
            search_name = input("Enter student name to search: ").strip()
            info = students.get(search_name)
            if info:
                print(f"Name: {search_name} - Untitled-1:60 - gradebook131.py:60")
                print(f"  Scores: {info['scores']} - Untitled-1:61 - gradebook131.py:61")
                print(f"  Average: {info['average']:.2f} - Untitled-1:62 - gradebook131.py:62")
                print(f"  Grade: {info['grade']} - Untitled-1:63 - gradebook131.py:63")
            else:
                print(f"Student '{search_name}' not found. - Untitled-1:65 - gradebook131.py:65")

        elif choice == '4':
            print("Exiting program. - Untitled-1:68 - gradebook131.py:68")
            break

        else:
            print("Invalid choice! Please enter a valid option. - Untitled-1:72 - gradebook131.py:72")


student_gradebook_manager()