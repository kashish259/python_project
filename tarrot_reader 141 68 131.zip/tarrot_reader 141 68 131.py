import tkinter as tk
from tkinter import messagebox, ttk, scrolledtext
import random
import datetime
from collections import deque, Counter
from enum import Enum
import threading
import queue
from typing import List, Dict, Optional, Any
import hashlib
from dataclasses import dataclass

# --- Constants and Data Definitions ---
RANKS = ['Ace', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'Jack', 'Queen', 'King']
SUITS = ['Hearts', 'Diamonds', 'Clubs', 'Spades']

_SUIT_MEANINGS = {
    'Hearts': {'primary': 'emotional life, relationships, home, inner feelings'},
    'Diamonds': {'primary': 'material wealth, resources, finances, values, security'},
    'Clubs': {'primary': 'action, work, creativity, social interaction, challenges'},
    'Spades': {'primary': 'intellect, challenges, endings, wisdom, transformation'}
}

_RANK_MEANINGS = {
    'Ace': {'primary': 'new beginnings, potential, opportunity'},
    '2': {'primary': 'balance, partnership, choice, duality'},
    '3': {'primary': 'growth, creation, collaboration, expansion'},
    '4': {'primary': 'stability, foundation, structure, boundaries'},
    '5': {'primary': 'change, conflict, instability, challenge'},
    '6': {'primary': 'harmony, generosity, responsibility, reconciliation'},
    '7': {'primary': 'reflection, introspection, mystery, spiritual growth'},
    '8': {'primary': 'movement, progress, mastery, power'},
    '9': {'primary': 'fulfillment, culmination, achievement, completion (almost)'},
    '10': {'primary': 'completion, endings, new cycles, burden'},
    'Jack': {'primary': 'youth, messenger, new ideas, adventure'},
    'Queen': {'primary': 'nurturing, intuition, inner wisdom, emotional maturity'},
    'King': {'primary': 'authority, mastery, leadership, external control'}
}

_CARD_MEANINGS = {
    ('Hearts', 'Ace'): ['A new emotional start, a surge of love or joy, deep emotional potential.'],
    ('Hearts', '2'): ['Partnership, union, mutual affection, a decision concerning relationships.'],
    ('Hearts', '3'): ['Celebration, friendship, community, joyful gatherings, emotional growth.'],
    ('Hearts', '4'): ['Emotional stability, feeling secure, contentment in relationships.'],
    ('Hearts', '5'): ['Emotional loss, grief, disappointment, a period of emotional upheaval.'],
    ('Hearts', '6'): ['Nostalgia, past memories, acts of kindness, healing from past wounds.'],
    ('Hearts', '7'): ['Choices in love, emotional illusions, multiple romantic opportunities.'],
    ('Hearts', '8'): ['Moving on from emotional situations, emotional detachment.'],
    ('Hearts', '9'): ['Emotional fulfillment, wishes coming true, contentment.'],
    ('Hearts', '10'): ['Complete emotional fulfillment, lasting joy, family harmony.'],
    ('Hearts', 'Jack'): ['A new emotional message, a young person with loving intentions.'],
    ('Hearts', 'Queen'): ['Compassionate leadership, nurturing wisdom, emotional intelligence.'],
    ('Hearts', 'King'): ['Emotional maturity, balanced emotions, wise leadership in relationships.'],
    ('Diamonds', 'Ace'): ['New financial opportunity, a tangible gift, a fresh start in material matters.'],
    ('Diamonds', '2'): ['Financial choices, balancing resources, managing money.'],
    ('Diamonds', '3'): ['Building something tangible, collaborative work, practical skills.'],
    ('Diamonds', '4'): ['Financial security, saving money, protecting assets.'],
    ('Diamonds', '5'): ['Financial hardship, material loss, poverty.'],
    ('Diamonds', '6'): ['Sharing wealth, generosity, charity, receiving or giving aid.'],
    ('Diamonds', '7'): ['Assessing investments, patience in financial endeavors.'],
    ('Diamonds', '8'): ['Hard work, dedication to craft, mastering skills.'],
    ('Diamonds', '9'): ['Financial independence, material success, luxury.'],
    ('Diamonds', '10'): ['Financial completion, generational wealth, ultimate material security.'],
    ('Diamonds', 'Jack'): ['News about money, a young person interested in business.'],
    ('Diamonds', 'Queen'): ['Financial wisdom, practical leadership, managing resources well.'],
    ('Diamonds', 'King'): ['Financial mastery, established wealth, strong business acumen.'],
    ('Clubs', 'Ace'): ['A new creative idea, a burst of energy, initiative for a project.'],
    ('Clubs', '2'): ['Balancing projects, making a choice about an action.'],
    ('Clubs', '3'): ['Collaborative creation, group efforts, expanding social circles.'],
    ('Clubs', '4'): ['Stable work, structured plans, reliable routine.'],
    ('Clubs', '5'): ['Conflict, challenge, disagreement, disruption in plans.'],
    ('Clubs', '6'): ['Victory, success after struggle, recognition for effort.'],
    ('Clubs', '7'): ['Courage in the face of challenge, standing firm, defending beliefs.'],
    ('Clubs', '8'): ['Rapid progress, swift action, moving quickly towards goals.'],
    ('Clubs', '9'): ['Strength, resilience, reaching a peak of effort.'],
    ('Clubs', '10'): ['Burden, overwork, responsibility, significant achievement.'],
    ('Clubs', 'Jack'): ['A new challenge, a young person with ideas, a message of action.'],
    ('Clubs', 'Queen'): ['Strong will, independent action, creative energy.'],
    ('Clubs', 'King'): ['Leadership in action, powerful decisions, taking charge.'],
    ('Spades', 'Ace'): ['A new insight, mental clarity, a breakthrough idea.'],
    ('Spades', '2'): ['Difficult decisions, mental stalemate, choosing between conflicting ideas.'],
    ('Spades', '3'): ['Heartbreak, sorrow, mental anguish, difficult truths.'],
    ('Spades', '4'): ['Rest, recovery, meditation, mental respite.'],
    ('Spades', '5'): ['Defeat, humiliation, conflict with unfair tactics.'],
    ('Spades', '6'): ['Moving away from difficulty, passage, journey towards clarity.'],
    ('Spades', '7'): ['Deception, hidden truths, strategic planning.'],
    ('Spades', '8'): ['Feeling trapped, mental limitations, self-imposed restrictions.'],
    ('Spades', '9'): ['Anxiety, nightmares, deep despair, extreme worry.'],
    ('Spades', '10'): ['Endings, painful conclusions, rock bottom, finality.'],
    ('Spades', 'Jack'): ['A message of truth, a critical young person, seeking knowledge.'],
    ('Spades', 'Queen'): ['Sharp intellect, discerning truth, objective judgment.'],
    ('Spades', 'King'): ['Intellectual authority, logical thinking, objective decision-making.']
}

# --- Core Classes ---

class CardOrientation(Enum):
    UPRIGHT = "Upright"
    REVERSED = "Reversed"

@dataclass
class TarotCard:
    name: str
    suit: str
    rank: str
    meaning: str
    orientation: CardOrientation = CardOrientation.UPRIGHT
    arcana_type: str = "Unknown"
    number: Optional[int] = None

    def __post_init__(self):
        self.reversed_meaning = f"The reversed {self.name} suggests challenges or an inward focus on: {self.meaning.lower().replace('a ', '', 1).replace('an ', '', 1)}"

    def get_meaning(self) -> str:
        return self.reversed_meaning if self.orientation == CardOrientation.REVERSED else self.meaning

class SpreadType(Enum):
    SINGLE = "Single Card"
    THREE_CARD = "Three Card Spread"
    CELTIC_CROSS = "Celtic Cross"
    RELATIONSHIP = "Relationship Spread"
    CAREER = "Career Path"
    ELEMENTAL_BALANCE = "Elemental Balance"

class ReadingContext:
    def __init__(self):
        self.context_data: Dict[str, str] = {}

    def add_context(self, key: str, value: str):
        self.context_data[key] = value

    def get_context(self) -> Dict[str, str]:
        return self.context_data

class TarotDeck:
    def __init__(self):
        self.all_cards: List[TarotCard] = []
        self.deck_for_drawing: deque = deque()
        self.card_name_index: Dict[str, TarotCard] = {}
        self.active_filters: Dict[str, Any] = {}
        self.load_cards()

    def _get_card_value(self, rank: str) -> int:
        if rank == 'Ace': return 1
        elif rank == 'Jack': return 11
        elif rank == 'Queen': return 12
        elif rank == 'King': return 13
        else: return int(rank)

    def _get_arcana_type(self, rank: str) -> str:
        if rank in ['Jack', 'Queen', 'King']: return 'Court Card'
        elif rank == 'Ace': return 'Ace Card'
        else: return 'Number Card'

    def load_cards(self):
        self.all_cards = []
        for suit in SUITS:
            for rank in RANKS:
                card_name = f"{rank} of {suit}"
                meaning = _CARD_MEANINGS.get((suit, rank), [''])[0]
                card = TarotCard(
                    name=card_name, suit=suit, rank=rank, meaning=meaning,
                    arcana_type=self._get_arcana_type(rank),
                    number=self._get_card_value(rank)
                )
                self.all_cards.append(card)
                self.card_name_index[card.name.lower()] = card
        self.reset_deck()

    def set_filters(self, filters: Dict[str, Any]):
        self.active_filters = filters
        self.reset_deck()

    def reset_deck(self):
        if not self.active_filters:
            filtered_cards = self.all_cards[:]
        else:
            filtered_cards = self.all_cards
            if 'suit' in self.active_filters and self.active_filters['suit'] != 'All':
                filtered_cards = [card for card in filtered_cards if card.suit == self.active_filters['suit']]
            if 'arcana_type' in self.active_filters and self.active_filters['arcana_type'] != 'All':
                filtered_cards = [card for card in filtered_cards if card.arcana_type == self.active_filters['arcana_type']]
        
        self.deck_for_drawing = deque(filtered_cards)
        self.shuffle()

    def shuffle(self):
        random.shuffle(self.deck_for_drawing)
        for card in self.deck_for_drawing:
            card.orientation = random.choice(list(CardOrientation))

    def draw(self, count: int = 1) -> List[TarotCard]:
        drawn = []
        for _ in range(min(count, len(self.deck_for_drawing))):
            drawn.append(self.deck_for_drawing.popleft())
        return drawn

    def get_remaining_count(self) -> int:
        return len(self.deck_for_drawing)

class TarotInterpreter:
    def __init__(self, deck: TarotDeck):
        self.deck = deck
        self.suit_meanings = _SUIT_MEANINGS
        self.rank_meanings = _RANK_MEANINGS

    def _interpret_card_text(self, card: TarotCard, position_name: str) -> str:
        orientation_text = f" ({card.orientation.value})"
        return (f"The {card.name}{orientation_text} in the '{position_name}' position "
                f"indicates: {card.get_meaning()}")

    def analyze_spread(self, spread_cards: List[TarotCard], position_meanings: List[str]) -> str:
        if not spread_cards:
            return "No cards were drawn."
        
        parts = ["--- Individual Card Interpretations ---\n"]
        for i, card in enumerate(spread_cards):
            pos_name = position_meanings[i] if i < len(position_meanings) else f"Card {i+1}"
            parts.append(self._interpret_card_text(card, pos_name))
        
        return "\n\n".join(parts)

class TarotCardReader:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("🔮 Text-Based Tarot Card Reader")
        self.root.geometry("1000x800")
        self.root.configure(bg="#2c3e50")
        
        self.deck = TarotDeck()
        self.interpreter = TarotInterpreter(self.deck)
        self.current_spread: List[TarotCard] = []
        self.spread_type = SpreadType.SINGLE
        self.reading_history: List[Dict] = []
        self.context = ReadingContext()
        
        self.setup_ui()

    def setup_ui(self):
        self.style = ttk.Style()
        self.style.theme_use('clam')
        self.style.configure("TButton", font=("Segoe UI", 12), padding=10, background="#3498db", foreground="#ffffff")
        self.style.map("TButton", background=[('active', '#2980b9')])
        self.style.configure("TLabel", font=("Segoe UI", 12), background="#2c3e50", foreground="#ecf0f1")
        self.style.configure("TFrame", background="#2c3e50")
        self.style.configure("TCombobox", font=("Segoe UI", 12), padding=5)
        self.style.configure("TEntry", font=("Segoe UI", 12), padding=5)

        # Main Title
        title_label = ttk.Label(self.root, text="Text-Based Tarot Reader", font=("Segoe UI", 28, "bold"))
        title_label.pack(pady=15)

        # Controls Frame
        control_frame = ttk.Frame(self.root)
        control_frame.pack(fill=tk.X, padx=10, pady=5)
        control_frame.columnconfigure(3, weight=1)

        ttk.Label(control_frame, text="Spread Type:").grid(row=0, column=0, padx=5, pady=5, sticky=tk.W)
        self.spread_selector = ttk.Combobox(control_frame, values=[e.value for e in SpreadType], state="readonly", width=20)
        self.spread_selector.set(SpreadType.SINGLE.value)
        self.spread_selector.bind("<<ComboboxSelected>>", self.on_spread_change)
        self.spread_selector.grid(row=0, column=1, padx=5, sticky=tk.W)

        ttk.Label(control_frame, text="Context:").grid(row=0, column=2, padx=(20, 5), pady=5, sticky=tk.W)
        self.context_entry = ttk.Entry(control_frame)
        self.context_entry.grid(row=0, column=3, padx=5, pady=5, sticky=tk.EW)
        self.context_entry.insert(0, "Enter your question or topic...")
        self.context_entry.bind("<FocusIn>", self.clear_placeholder)
        self.context_entry.bind("<FocusOut>", self.restore_placeholder)

        # Spread Display Area (replaces canvas)
        self.spread_display_text = scrolledtext.ScrolledText(
            self.root, height=12, wrap=tk.WORD, font=("Courier New", 14, "bold"), 
            bg="#34495e", fg="#ecf0f1", padx=15, pady=15
        )
        self.spread_display_text.pack(pady=10, fill=tk.BOTH, expand=True, padx=10)
        self.spread_display_text.tag_configure("center", justify='center')
        self.spread_display_text.tag_configure("position", foreground="#3498db", font=("Segoe UI", 16, "bold"))
        self.spread_display_text.tag_configure("card_name", foreground="#ffffff", font=("Courier New", 14, "bold"))
        self.spread_display_text.tag_configure("orientation", foreground="#bdc3c7", font=("Courier New", 12, "italic"))
        self.spread_display_text.config(state='disabled')


        # Interpretation Area (the "down side" message display)
        self.result_text = scrolledtext.ScrolledText(
            self.root, height=10, wrap=tk.WORD, font=("Segoe UI", 12), 
            bg="#ecf0f1", fg="#2c3e50", padx=10, pady=10
        )
        self.result_text.pack(pady=10, fill=tk.X, padx=10)
        self.result_text.config(state='disabled')

        # Buttons Frame
        button_frame = ttk.Frame(self.root)
        button_frame.pack(pady=15)
        
        self.draw_btn = ttk.Button(button_frame, text="Draw Spread", command=self.draw_spread)
        self.draw_btn.grid(row=0, column=0, padx=10)
        self.shuffle_btn = ttk.Button(button_frame, text="Shuffle Deck", command=self.shuffle_deck)
        self.shuffle_btn.grid(row=0, column=1, padx=10)
        self.history_btn = ttk.Button(button_frame, text="View History", command=self.show_history)
        self.history_btn.grid(row=0, column=2, padx=10)
        self.exit_btn = ttk.Button(button_frame, text="Exit", command=self.root.quit)
        self.exit_btn.grid(row=0, column=3, padx=10)

        # Status Label
        self.status_label = ttk.Label(self.root, text=f"Deck has {self.deck.get_remaining_count()} cards.", anchor='center')
        self.status_label.pack(pady=5, fill=tk.X)

    def on_spread_change(self, event):
        self.spread_type = SpreadType(self.spread_selector.get())
        self.clear_displays()

    def clear_placeholder(self, event):
        if self.context_entry.get() == "Enter your question or topic...":
            self.context_entry.delete(0, tk.END)

    def restore_placeholder(self, event):
        if not self.context_entry.get():
            self.context_entry.insert(0, "Enter your question or topic...")

    def shuffle_deck(self):
        self.deck.reset_deck()
        self.status_label.config(text=f"Deck shuffled. {self.deck.get_remaining_count()} cards ready.")
        self.clear_displays()
        messagebox.showinfo("Deck Shuffled", "The full deck has been shuffled.")

    def draw_spread(self):
        self.clear_displays()

        spread_configs = {
            SpreadType.SINGLE: {"count": 1, "meanings": ["The Outcome"]},
            SpreadType.THREE_CARD: {"count": 3, "meanings": ["The Past", "The Present", "The Future"]},
            SpreadType.CELTIC_CROSS: {"count": 10, "meanings": ["1. Present", "2. Challenge", "3. Past", "4. Future", "5. Above", "6. Below", "7. Your Role", "8. Environment", "9. Hopes/Fears", "10. Outcome"]},
            SpreadType.RELATIONSHIP: {"count": 7, "meanings": ["You", "Your Partner", "The Dynamic", "Your Needs", "Partner's Needs", "Obstacles", "Potential"]},
            SpreadType.CAREER: {"count": 5, "meanings": ["Current Role", "Challenges", "Opportunities", "Advice", "Final Outcome"]},
            SpreadType.ELEMENTAL_BALANCE: {"count": 4, "meanings": ["Hearts (Emotions)", "Diamonds (Material)", "Clubs (Action)", "Spades (Intellect)"]}
        }
        
        config = spread_configs[self.spread_type]
        num_to_draw = config["count"]

        if self.deck.get_remaining_count() < num_to_draw:
            messagebox.showwarning("Not Enough Cards", f"Deck has only {self.deck.get_remaining_count()} cards left. Please shuffle.")
            return

        self.current_spread = self.deck.draw(num_to_draw)
        
        # Display cards in the top text area
        self.spread_display_text.config(state='normal')
        for i, card in enumerate(self.current_spread):
            pos_meaning = config["meanings"][i]
            self.spread_display_text.insert(tk.END, f"--- {pos_meaning} ---\n", ("position", "center"))
            self.spread_display_text.insert(tk.END, f"{card.name}\n", ("card_name", "center"))
            self.spread_display_text.insert(tk.END, f"({card.orientation.value})\n\n", ("orientation", "center"))
        self.spread_display_text.config(state='disabled')
        
        # Display interpretation in the bottom text area
        self.display_interpretation(config["meanings"])
        
        self.status_label.config(text=f"Cards remaining: {self.deck.get_remaining_count()}")
        self.save_current_reading_to_history()

    def display_interpretation(self, meanings):
        self.result_text.config(state='normal')
        self.result_text.delete(1.0, tk.END)
        
        interpretation = self.interpreter.analyze_spread(self.current_spread, meanings)
        self.result_text.insert(tk.END, interpretation)
        self.result_text.config(state='disabled')

    def clear_displays(self):
        self.spread_display_text.config(state='normal')
        self.spread_display_text.delete(1.0, tk.END)
        self.spread_display_text.config(state='disabled')
        
        self.result_text.config(state='normal')
        self.result_text.delete(1.0, tk.END)
        self.result_text.config(state='disabled')

    def save_current_reading_to_history(self):
        context_text = self.context_entry.get()
        if context_text == "Enter your question or topic...":
            context_text = "General Reading"

        reading = {
            "timestamp": datetime.datetime.now().isoformat(),
            "spread_type": self.spread_type.value,
            "cards": [{"name": c.name, "orientation": c.orientation.value, "meaning": c.get_meaning()} for c in self.current_spread],
            "context": context_text
        }
        self.reading_history.append(reading)

    def show_history(self):
        history_window = tk.Toplevel(self.root)
        history_window.title("Reading History")
        history_window.geometry("700x500")
        history_window.configure(bg="#2c3e50")
        
        history_text = scrolledtext.ScrolledText(history_window, wrap=tk.WORD, font=("Segoe UI", 11), bg="#ecf0f1")
        history_text.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        history_text.tag_configure("header", font=("Segoe UI", 12, "bold"), foreground="#3498db")
        history_text.tag_configure("context", font=("Segoe UI", 11, "italic"))

        if not self.reading_history:
            history_text.insert(tk.END, "No reading history found in this session.")
        else:
            for reading in reversed(self.reading_history):
                ts = datetime.datetime.fromisoformat(reading['timestamp']).strftime('%Y-%m-%d %H:%M:%S')
                history_text.insert(tk.END, f"Time: {ts}\n", "header")
                history_text.insert(tk.END, f"Spread: {reading['spread_type']}\n", "header")
                history_text.insert(tk.END, f"Context: {reading['context']}\n", "context")
                history_text.insert(tk.END, "Cards Drawn:\n")
                for card_data in reading['cards']:
                    history_text.insert(tk.END, f"  - {card_data['name']} ({card_data['orientation']})\n")
                history_text.insert(tk.END, "\n" + "-"*60 + "\n\n")
        
        history_text.config(state='disabled')

if __name__ == "__main__":
    try:
        root = tk.Tk()
        app = TarotCardReader(root)
        root.mainloop()
    except Exception as e:
        messagebox.showerror("Fatal Error", f"A critical error occurred: {e}")